pub mod waveform;
pub mod midi;
pub mod synth;
pub mod wavetable;